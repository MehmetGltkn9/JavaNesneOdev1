
package com.mycompany.ui;
import javax.swing.JFrame;
public class UI {
    public static void main(String[] args) {
        GUI g=new GUI();
        g.setSize(500,500);
        g.setVisible(true);
        g.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);     
    }
}
