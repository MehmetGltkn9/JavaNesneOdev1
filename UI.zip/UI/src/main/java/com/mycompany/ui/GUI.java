package com.mycompany.ui;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
public class GUI extends JFrame implements ActionListener{
    JPanel jpanel;
    JButton bLogin,bList;
    JLabel user,userPassword;
    final JTextField userName,password;
    public GUI() {
        bList=new JButton("Listele");
        bList.setBounds(275, 220, 100, 30);
        bLogin=new JButton("Login");
        bLogin.setBounds(125,220,100,30);
        userName=new JTextField();
        userName.setBounds(275, 100, 100, 25);
        password=new JTextField();
        password.setBounds(275, 150, 100, 25);
        user=new JLabel("Kullanıcı Adı :");
        user.setBounds(125,100,100,25);
        userPassword=new JLabel("Sifre :");
        userPassword.setBounds(125,150,100,25); 
        jpanel=new JPanel();
        jpanel.setLayout(null);
        jpanel.add(user);
        jpanel.add(userPassword);
        jpanel.add(password);
        jpanel.add(userName);
        jpanel.add(bList);
        jpanel.add(bLogin);
        add(jpanel);
        bLogin.addActionListener(this);
        bList.addActionListener(this);
    }
    @Override
    public void actionPerformed(ActionEvent GUI) {
        Controll c=new Controll();
        
        String userNameVal=userName.getText();
        String passwordVal=password.getText();
        
        if(GUI.getSource()==bLogin){
            try {
                c.Yazma(userNameVal,passwordVal);
            } catch (IOException ex) {
                Logger.getLogger(GUI.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        else if(GUI.getSource()==bList){
            try {
                c.Okuma();
            } catch (IOException ex) {
                Logger.getLogger(GUI.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }    
}
