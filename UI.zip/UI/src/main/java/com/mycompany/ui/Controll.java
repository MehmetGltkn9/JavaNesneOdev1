package com.mycompany.ui;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
public class Controll{ 
    public void Yazma(String userNameVal, String passwordVal) throws IOException{
        File Dosya=new File("C:\\Users\\mehmet\\Documents\\NetBeansProjects\\UI\\src\\main\\java\\com\\mycompany\\ui\\Dosya.txt");
        FileWriter fYazma=new FileWriter(Dosya, true);
        try (BufferedWriter bYazma = new BufferedWriter(fYazma)) {
            bYazma.append(userNameVal + "  ");
            bYazma.append(passwordVal + "\n");
            System.out.println("");
        }
        catch(IOException e){
            System.out.println("/hata :"+e.getMessage());
        }
    }
    public void Okuma() throws IOException{
        File Dosya=new File("C:\\Users\\mehmet\\Documents\\NetBeansProjects\\UI\\src\\main\\java\\com\\mycompany\\ui\\Dosya.txt");
        FileReader fOkuma=new FileReader(Dosya);
        String line;
        System.out.println("Liste : ");    
        try (BufferedReader bOkuma = new BufferedReader(fOkuma)) {
            while((line=bOkuma.readLine()) != null){
                System.out.println(line);
            }
        }
        catch(IOException e){
            System.out.println("/hata :"+e.getMessage());
        }
    }
}
